package snek;

import java.awt.Point;

public class Snake {
    
    private Segment[] segments;
    private Segment head;

    public Snake(int segmentNumber, Point spawn) {
        segments = new Segment[segmentNumber];
        for (int i = 0; i < segmentNumber; i++) {
            segments[i] = new Segment(spawn.x, spawn.y + i, Direction.N);
        }
        head = segments[0];
    }
    
    public Point[] getCoordinates() {
        Point[] temp = new Point[segments.length];
        for (int i = 0; i < segments.length; i++) {
            temp[i] = segments[i].getCoordinates();
        }
        return temp;
    }
    
    public void moveFromBack() {
        // hátulról vagy kettővel szereted?
        
        //hátulról:
        for (int i = segments.length-1; i > 0; i--) {
            segments[i].setCoordinates(segments[i-1].getCoordinates());
        }
        head.setCoordinates(new Point(
                head.getCoordinates().x + head.getDirection().getX(),
                head.getCoordinates().y + head.getDirection().getY())
        );
        
        
    }
    
    public void moveFromHead() {
        //két ideiglenes változóval:
    }
    
//    private void moveHead() {
//        switch (head.) {
//            case val:
//                
//                break;
//            default:
//                throw new AssertionError();
//        }
//    }
    
    public void changeDirection(Direction d) {
        head.setDirection(d);
    }
    
}
