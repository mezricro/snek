package snek;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import javax.swing.Timer;


public class Game {
    
    Snake snek;
    Map map;
    Display display = new Display();
    Timer timer;

    public Game() {
        map = new Map(50, 50);
        snek = new Snake(10, map.getSpawn());
        timerSetup();
    }
    
    //Generate a new BufferedImage from an existing one
    private BufferedImage deepCopy(BufferedImage source) {
        BufferedImage b = new BufferedImage(source.getWidth(), source.getHeight(), source.getType());
        Graphics g = b.getGraphics();
        g.drawImage(source, 0, 0, null);
        g.dispose();
        return b;
    }
    
    
    private void updateGamestate() {
        snek.moveFromBack();
    }
    
    private Image getGameState() {
       BufferedImage gameState = deepCopy(map);
       
       boolean isHead = true;
       for(Point px : snek.getCoordinates()) {
           if (isHead) {
               gameState.setRGB(px.x, px.y, Color.GREEN.getRGB());
               isHead = false;
           } else {
                gameState.setRGB(px.x, px.y, Color.WHITE.getRGB());   
           }
       }
        
       return getScaled(gameState, 15);
    };
    
    private Image getScaled(BufferedImage img, int scale) {
        return img.getScaledInstance(img.getWidth() * scale, img.getHeight() * scale, Image.SCALE_FAST);
    }
    
    private void timerSetup() {
        timer = new Timer(300, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                updateGamestate();
                display.updateDisplay(getGameState());
            }
        });
        timer.start();
        display.disp.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                switch (e.getKeyCode()) {
                    case KeyEvent.VK_LEFT: snek.changeDirection(Direction.W); break;
                    case KeyEvent.VK_RIGHT: snek.changeDirection(Direction.E); break;
                    case KeyEvent.VK_UP: snek.changeDirection(Direction.N); break;
                    case KeyEvent.VK_DOWN: snek.changeDirection(Direction.S); break;
                }
            }
        });
    }
    
    
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Game g = new Game();
        
        EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                g.display.updateDisplay(g.getGameState());
                g.display.setVisible(true);
            }
        });
    }
    
}
