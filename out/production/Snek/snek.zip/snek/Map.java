package snek;

import java.awt.Point;
import java.awt.image.BufferedImage;

public class Map extends BufferedImage{
    
    private Point spawn;
    
    public Map(int width, int height, Point spawn) {
        super(width, height, BufferedImage.TYPE_INT_RGB);
        this.spawn = spawn;
    }
    
    public Map(int width, int height) {
        this(width, height, new Point(width / 2, height / 2));
    }

    public Point getSpawn() {
        return spawn;
    }
    
    
}
